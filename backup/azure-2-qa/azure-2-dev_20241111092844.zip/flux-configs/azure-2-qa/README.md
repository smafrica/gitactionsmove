# gitactionsmove
Move files for path release (ex. k8s flux deployments) with Github Actions
